function submitForm() {
    // Aqui você pode adicionar o código para processar o formulário de contato
    // Por exemplo: validar os campos e enviar os dados via AJAX
    alert("Formulário de contato enviado!");
}

function submitNewsletter() {
    // Aqui você pode adicionar o código para processar o formulário de newsletter
    // Por exemplo: validar o campo de email e enviar os dados via AJAX
    alert("Você se inscreveu na newsletter!");
}
